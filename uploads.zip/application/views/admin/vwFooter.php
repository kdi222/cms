</div><!-- /#wrapper -->
    <script src="<?php echo HTTP_JS_PATH; ?>tablesorter/jquery.tablesorter.js"></script>
    <script src="<?php echo HTTP_JS_PATH; ?>tablesorter/tables.js"></script>

  </body>
</html>